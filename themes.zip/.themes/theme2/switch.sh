#!/bin/sh
if [ -f "/mnt/sd_0/script.sh" ]; then
  sh "/mnt/sd_0/script.sh"
fi

if [ -f "/mnt/sd_0/.themes/theme3/switch.sh" ]; then
  cp -r "/mnt/sd_0/.themes/theme3/." "/usr/resource/gui/theme1/"
else
  cp -rs "/usr/resource/gui/themes/theme1/." "/usr/resource/gui/theme1/"
fi
